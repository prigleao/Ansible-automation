# Sample Python Scripts of ZTP
This repo contains some sample scripts for Zero Touch Deployment on Cisco devices.  Requires IOS-XE 16.6 or
later.

### script 
contains examples for the python scripts

### Node-red
contains a sample server for mapping serial number to atrtibutes (such as management IP address etc) for devices

### py-server
A pure python version of this sample server

More to come